
package main;
import java.util.Scanner;

public class Main2 {
    public static void main(String[] args) {
    Scanner input = new Scanner(System.in);
    String client_name,client_addrerss,client_account;
    int client_phone,client_nationalID,client_commericalID,client_balance,client_account_number;
    System.out.println(" Enter (1) for normal Client");
    System.out.println(" Enter (2) for Commercial Client");
    int a;
    a=input.nextInt();
    switch(a)
    {
        case 1:
            
            System.out.println(" Enter your name");
            client_name=input.next();
            System.out.println(" Enter your National ID");
            client_nationalID=input.nextInt();
            System.out.println(" Enter your Address");
            client_addrerss=input.next();
            System.out.println(" Enter your phone");
            client_phone=input.nextInt();
            System.out.println(" Enter your account(email)");
            client_account=input.next();
            System.out.println(" Enter your account balance");
            client_balance = input.nextInt();
            System.out.println(" Enter your account number");
            client_account_number = input.nextInt();
            
            Account ui= new Account(client_balance,client_account_number);
            Client qr= new Client(client_name,client_nationalID,client_addrerss,client_phone,client_account,ui);
            System.out.println("Enter (yes) if you want to review the information you entered");
            System.out.println("Enter (no) if you want to review the information you entered");
            String e;
            e= input.next();
            switch(e)
            {
                case "yes":
                    System.out.println(qr);
                    break;
                case "no":
                    System.out.println("Thank you");
                    break;
            
            }
            
            break;
        case 2:
            System.out.println(" Enter your name");
            client_name=input.next();
            System.out.println(" Enter your commerical ID");
            client_commericalID=input.nextInt();
            System.out.println(" Enter your Address");
            client_addrerss=input.next();
            System.out.println(" Enter your phone");
            client_phone=input.nextInt();
            System.out.println(" Enter your account(email)");
            client_account=input.next();
            System.out.println(" Enter your account balance");
            client_balance = input.nextInt();
            System.out.println(" Enter your account number");
            client_account_number = input.nextInt();
            
            Account u= new Account(client_balance,client_account_number);
            Client q= new CommercialClient(client_name,client_commericalID,client_addrerss,client_phone,client_account,u);
            System.out.println("Enter (yes) if you want to review the information you entered");
            System.out.println("Enter (no) if you want to review the information you entered");
            e= input.next();
            switch(e)
            {
                case "yes":
                    System.out.println(q);
                    break;
                case "no":
                    System.out.println("Thank you");
                    break;
            
            }
            
            break;
                        
    
    
    }
    
    
    
    
    }
    
}
