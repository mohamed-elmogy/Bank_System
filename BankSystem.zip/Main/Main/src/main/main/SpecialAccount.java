/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main;

/**
 *
 * @author a
 */
public class SpecialAccount extends Account {

    public SpecialAccount(int b, int a) {
        super(b, a);
    }
    
    public void withdraw(int required_withdraw_amount){
            int over_drafting;
        if (required_withdraw_amount>=get_Account_balance()){
            
              over_drafting=get_Account_balance()-required_withdraw_amount;
              if(over_drafting<-1000){
                   System.out.println("the amount of required balace is greater than -1000");
              }
              else{
              System.out.println("your account balance = "+ over_drafting);
              }
        
        }
        else {
            over_drafting=get_Account_balance()-required_withdraw_amount;
            System.out.println("your account balance = "+over_drafting); 
        
        }
       
     
    }
    
}
