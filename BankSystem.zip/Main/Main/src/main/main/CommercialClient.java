
package main;


public class CommercialClient extends Client {
    public int commercialID;
    public int NationalID;
    public CommercialClient(String n, int cD, String a, int p, String ac, Account obj) {
        super(n, cD, a, p, ac, obj);
        commercialID=cD;
        
    }
    
    
    public void set_commercialID(int a){
    
    this.commercialID=a;
    }
    public int get_commercialID(){
    
    return commercialID;
    } 
    public void set_nationalID()
    {
       NationalID=00000000000000;
    
    }
     public int get_NationalID(){
    
       return NationalID;
    } 
    public String toString() {
        return String.format("Name is " + get_name()+"\n"+" commercial ID = " +commercialID+"\n"+"National Id = "+get_NationalID()+"\n" +"Address is " + get_address() + "\n" +"phone is " +get_phone() +"\n" +"your account is "+ get_account() +"\n"+ " account balance = "+ object.get_Account_balance()+"\n" + "the account number = " + object.get_Account_number() ); 
    }
}