/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main;

/**
 *
 * @author a
 */
public class Account {
    private int balance;
    private int account_number;
    public Account(int b,int a){
    balance=b;
    account_number=a;
    
    }
    public void setbalance(int b){
    
    this.balance=b;
    }
     public void set_acount_number(int a){
    
    this.balance=a;
    }
    public int get_Account_balance(){
    
    return balance;
    } 
    public int get_Account_number(){
    
    return account_number;
    }
    @Override
    public String toString() {
        return String.format("your Account number ="+get_Account_number()+"\n"+"your Account balance ="+get_Account_balance()+"$");
        
    }
   
    public void withdraw(int required_withdraw_amount){
        int result=0;
    if (required_withdraw_amount<=balance)
    {
       result=balance-required_withdraw_amount;
       System.out.println("your account balance became =" + result);
    
    }
    else
    {
    System.out.println("your account balance can not afford the required withdraw  ammount");
    }
        
    
      
    }
    public void  deposit(int required_deposit_amount){
        int total;
        total = balance+required_deposit_amount;
        System.out.println("your account balance became =" + total);
        
        
    }
    
    
}
