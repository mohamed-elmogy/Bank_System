package main;

public class Main3 {
	public static void main(String args[])
	{
		SpecialAccount a = new SpecialAccount(300000,30201010),a2 = new SpecialAccount(300000,30201010);
		
		CommercialClient client = new CommercialClient("mohamed",30201010,"mohamed said ahmed",01027133357,"30201010A",a),c=new CommercialClient("mohamed",30201010,"mohamed said ahmed",01027133357,"30201010A",a);
		Bank bank=new Bank("cib","mohamed.said.ahmed","01027133357");
		bank.set_address("mohamed.said.ahmed");
		bank.add_client_account(client, a);
		bank.add_client_account(c, a2);
		bank.display_all();
		
	}
}
