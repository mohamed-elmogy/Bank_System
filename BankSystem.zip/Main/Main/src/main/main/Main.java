package main;

import java.util.Scanner;


public class Main {

  
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int x,y;
        System.out.println("enter your account balance");
        x = input.nextInt();
        System.out.println("enter your account number");
        y = input.nextInt();
        
        
        Account obj=new Account(x,y);
        System.out.println(obj);
        System.out.println("Enter (1) for  normal Account");
        System.out.println("Enter (2) for Special Account");
        int z;
        z= input.nextInt();
        switch(z)
        {
            case 1:
                System.out.println("Enter (1) for deposit ");
                System.out.println("Enter (2) for withdraw ");
                int p;
                p=input.nextInt();
                switch(p)
                {
                    case 1:
                        System.out.println("Enter the amount you want to deposit ");
                        int number_deposit;
                        number_deposit=input.nextInt();
                        obj.deposit(number_deposit);
                        break;
                    case 2:
                        System.out.println("Enter the amount you want to withdraw ");
                        int number_withdraw;
                        number_withdraw=input.nextInt();
                        obj.withdraw(number_withdraw);
                        break;
                
                
                }
                break;
            case 2:
                Account obj1 = new SpecialAccount(x,y);
                System.out.println("Enter (1) for deposit ");
                System.out.println("Enter (2) for withdraw ");
                int w;
                w=input.nextInt();
                 switch(w)
                {
                    case 1:
                        System.out.println("Enter the amount you want to deposit ");
                        int number_deposit;
                        number_deposit=input.nextInt();
                        obj1.deposit(number_deposit);
                        break;
                    case 2:
                        System.out.println("Enter the amount you want to withdraw ");
                        int number_withdraw;
                        number_withdraw=input.nextInt();
                        obj1.withdraw(number_withdraw);
                        break;
                
                
                }
                break;
                
                
        
        
        
        }
        
       
        
    }
    
}
