package main;

public class Bank {
	private String Name;
	private	String Address;
	private	String Phone;
	private int number;
	private int limit=1;
	private	Account account[]=new Account[limit];
	private Client client[]=new Client[limit];
	public Bank(String name, String address, String phone) {
		Name=name;
		Address=address;
		Phone=phone;
	}
	public void set_name(String name) {
		Name=name;
	}
	public void set_address(String address) {
		Address=address;
	}
	public void set_phone(String phone) {
		Phone=phone;
	}
	public String get_address() {
		return Address;
	}
	public String get_name() {
		return Name;
	}
	public String get_phone() {
		return Phone;
	}
	void ensure() {
		if(number>=limit)
		{
			Client array[]=new Client[++limit];
			Account arr[]=new Account[limit];
			for(int i=0;i<number;i++)
			{
				array[i]=client[i];
				arr[i]=account[i];
			}
			client=array;
			account=arr;
		}
	}
	public void add_client_account(Client c, Account a)
	{
		ensure();
		client[number]=c;
		account[number++]=a;
		
	}
	public void display_all()
	{
		for(int i=0;i<number;i++)
		{
                        System.out.println("****************************** client "+i+1+" *************");
			System.out.println("client:"+client[i]+"\naccount:"+account[i]);
                        System.out.println("**********************************************************");
		}
	}
        public Account search_Account(int account_number)
        {
            
            for(int i=0 ;i<=number ; i++)
            {
                
                if(account[i].get_Account_number()==account_number)
                {
                    return account[i];
                
                
                }
            
            }
            
           return null; 
        }
	
}
