/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main;

/**
 *
 * @author a
 */
public class Account {
    private int balance;
    private int account_number;
    public Account(int a,int b){
    balance=b;
    account_number=a;
    
    }
    public Account(Account ok)
    {
    this.balance=ok.balance;
    this.account_number=ok.account_number;
    
    }
    public void setbalance(int b){
    
    this.balance=b;
    }
     public void set_acount_number(int a){
    
    this.balance=a;
    }
    public int get_Account_balance(){
    
    return balance;
    } 
    public int get_Account_number(){
    
    return account_number;
    }
    @Override
    public String toString() {
        return String.format("your Account number ="+get_Account_number()+"\n"+"your Account balance ="+get_Account_balance()+"$");
        
    }
   
    public void withdraw(int required_withdraw_amount){
        
    if (required_withdraw_amount<=balance)
    {
       balance=balance-required_withdraw_amount;
       System.out.println("your account balance became =" + balance);
    
    }
    else
    {
    System.out.println("your account balance can not afford the required withdraw  ammount");
    }
        
    
      
    }
    public void  deposit(int required_deposit_amount){
        balance = balance+required_deposit_amount;
        System.out.println("your account balance became =" + balance);
        
        
    }
    
    
}
