
package main;
import java.util.Scanner;

public class bankmenu {

  
    public static void main(String[] args) {
        
        Scanner input = new Scanner (System.in);
        int choice=0;
        
        Bank g= new Bank("bank_AlAhly","Dokki","01202856987");
        while(choice!=4){
                System.out.println(" 1- Add new client");
                System.out.println(" 2- list all Accounts/Clients");
                System.out.println(" 3- withdraw / deposit ");
                System.out.println(" 4- exit");
                choice= input.nextInt();
        switch(choice)
        {
             
            case 1:
                
                String client_name,client_addrerss,client_account;
                int client_phone,client_nationalID,client_commericalID,client_balance,client_account_number;
                System.out.println(" Enter (1) for normal Client");
                System.out.println(" Enter (2) for Commercial Client");
                int a;
                a=input.nextInt();
                
                
                
               switch(a)
    {
        case 1:
                
            System.out.println(" Enter your name");
            client_name=input.next();
            System.out.println(" Enter your National ID");
            client_nationalID=input.nextInt();
            System.out.println(" Enter your Address");
            client_addrerss=input.next();
            System.out.println(" Enter your phone");
            client_phone=input.nextInt();
            System.out.println(" Enter your account(email)");
            client_account=input.next();
            System.out.println(" Enter your account balance");
            client_balance = input.nextInt();
            System.out.println(" Enter your account number");
            client_account_number = input.nextInt();
            System.out.println("Enter (1) for  normal Account");
                System.out.println("Enter (2) for Special Account");
                int z;
                z= input.nextInt();
                switch(z)
                {
                    case 1:
                        Account l=new Account(client_account_number,client_balance);
                        Client qr= new Client(client_name,client_nationalID,client_addrerss,client_phone,client_account,l);
                        System.out.println("Enter (yes) if you want to review the information you entered");
                        System.out.println("Enter (no) if you want to review the information you entered");
                        String e;
                        e= input.next();
                        g.add_client_account(qr, l);
                        switch(e)
                        {
                            case "yes":
                                System.out.println(qr);
                                break;
                            case "no":
                                System.out.println("Thank you");
                                break;

                        }
                        break;
                    case 2:
                        Account k=new SpecialAccount(client_account_number,client_balance);
                        Client r= new Client(client_name,client_nationalID,client_addrerss,client_phone,client_account,k);
                        System.out.println("Enter (yes) if you want to review the information you entered");
                        System.out.println("Enter (no) if you want to review the information you entered");
 
                        e= input.next();
                        g.add_client_account(r, k);
                        switch(e)
                        {
                            case "yes":
                                System.out.println(r);
                                break;
                            case "no":
                                System.out.println("Thank you");
                                break;

                        }
                        break;        
                
                }
            
            
            
            break;
        case 2:
            System.out.println(" Enter your name");
            client_name=input.next();
            System.out.println(" Enter your commerical ID");
            client_commericalID=input.nextInt();
            System.out.println(" Enter your Address");
            client_addrerss=input.next();
            System.out.println(" Enter your phone");
            client_phone=input.nextInt();
            System.out.println(" Enter your account(email)");
            client_account=input.next();
            System.out.println(" Enter your account balance");
            client_balance = input.nextInt();
            System.out.println(" Enter your account number");
            client_account_number = input.nextInt();
            
            
            System.out.println("Enter (1) for  normal Account");
                System.out.println("Enter (2) for Special Account");
                
                z= input.nextInt();
                switch(z)
                {
                    case 1:
                        Account l=new Account(client_account_number,client_balance);
                        Client qr= new CommercialClient(client_name, client_commericalID,client_addrerss,client_phone,client_account,l);
                        System.out.println("Enter (yes) if you want to review the information you entered");
                        System.out.println("Enter (no) if you want to review the information you entered");
                        String e;
                        e= input.next();
                        g.add_client_account(qr, l);
                        switch(e)
                        {
                            case "yes":
                                System.out.println(qr);
                                break;
                            case "no":
                                System.out.println("Thank you");
                                break;

                        }
                        break;
                    case 2:
                        Account k=new SpecialAccount(client_account_number,client_balance);
                        Client r= new CommercialClient(client_name,client_commericalID,client_addrerss,client_phone,client_account,k);
                        System.out.println("Enter (yes) if you want to review the information you entered");
                        System.out.println("Enter (no) if you want to review the information you entered");
 
                        e= input.next();
                        g.add_client_account(r, k);
                        switch(e)
                        {
                            case "yes":
                                System.out.println(r);
                                break;
                            case "no":
                                System.out.println("Thank you");
                                break;

                        }
                        break;        
                
                }
            
            
            break;
                        
    
    
    }
               break;
            case 2:
                g.display_all();
                break;
            case 3:
                
               
                System.out.println("enter your account number");
                int x;
                x = input.nextInt();
  
                System.out.println("1- withdraw");
                System.out.println("2- Deposit");
                int p;
                p=input.nextInt();
                switch(p)
                {
                    case 1:
                        int amount_withdraw;
                        System.out.println("Enter amount withdraw");
                        amount_withdraw=input.nextInt();
                        g.search_Account(x).withdraw(amount_withdraw);
                        break;
                    case 2:
                        int amount_deposit;
                        System.out.println("Enter amount deposit");
                        amount_deposit=input.nextInt();
                        g.search_Account(x).deposit(amount_deposit);
                        break;                    
                }
                
                
                break;
            case 4:
                break;
        }
        
        }
        
    }
}
