
package main;


public class Client {
    private String name;
    private int nationalID;
    private String address;
    private int phone;
    private String account;
    public Account object;
    public Client(String n,int nD,String a,int p , String ac, Account obj)
    {
        name=n;
        nationalID=nD;
        address=a;
        phone=p;
        account=ac;
        object=obj;
    
    }
     public void set_name(String n){
    
        this.name=n;
    }
     public void set_nationalID(int nD){
    
        this.nationalID=nD;
    }
      public void set_address(String a){
    
        this.address=a;
    }
      public void set_phone(int p){
    
        this.phone=p;
    }
      public void set_account(String ac){
    
        this.account=ac;
    }
      public void set_Account(Account ob){
    
        this.object=ob;
    }
    public String get_name(){
    
        return name;
    } 
    public int get_nationalID(){
    
       return nationalID;
    } 
     public String get_address(){
    
       return address;
    } 
      public int get_phone(){
    
       return phone;
    } 
       public String get_account(){
    
       return account;
    }   
    public Account get_Account(){
    
      return object;
    } 
     @Override
    public String toString() {
        return String.format("Name is " + name+"\n"+" National ID = " +nationalID+"\n"+"Address is " + address + "\n" +"phone is " +phone +"\n" +"your account is "+ account +"\n"+ " account balance = "+ object.get_Account_balance()+"\n" + "the account number = " + object.get_Account_number());
        
    }
    
    
    
}
